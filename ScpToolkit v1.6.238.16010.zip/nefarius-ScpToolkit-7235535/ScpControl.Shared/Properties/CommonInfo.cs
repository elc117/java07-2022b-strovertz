﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

[assembly: AssemblyCompany("Scarlet.Crush Productions")]
[assembly: AssemblyCopyright("Copyright © Scarlet.Crush Productions 2012-2014, Benjamin Höglinger 2015")]

//[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

[assembly: ComVisible(false)]

[assembly: AssemblyVersion("1.6.232.16004")]
[assembly: AssemblyFileVersion("1.6.232.16004")]