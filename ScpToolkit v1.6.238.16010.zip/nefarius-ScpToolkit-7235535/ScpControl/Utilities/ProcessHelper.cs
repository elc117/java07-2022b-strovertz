﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ScpControl.ScpCore;

namespace ScpControl.Utilities
{
    public class ProcessHelper : SingletonBase<ProcessHelper>
    {
    }
}
